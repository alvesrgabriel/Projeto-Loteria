<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado - LotoGru</title>
    <link rel="stylesheet" href="resultado.css"> 
    <meta http-equiv="refresh" content="10;url=index.php"> <!-- Redireciona após 10 segundos -->
</head>
<body>
    <div>
        <p class="titulo">Resultado do Sorteio</p>
        <?php
            $nome = $_POST['nome'];
            $aposta = $_POST['aposta'];
            $valores = $_POST['valores'] ?? null;

            if ($valores === null || count($valores) != 25) {
                echo "Você deve escolher exatamente 25 números!";
                exit;
            }

            $sorteio = array_rand(range(1, 50), 25);

            $acertos = array_intersect($valores, $sorteio);
            $total_acertos = count($acertos);

            if ($total_acertos == 25 || $total_acertos == 0) {
                $premio = 50 * $aposta;
                echo $nome . ", você acertou " . $total_acertos . " números e ganhou R$ " . $premio . "!<br>";
            } else {
                echo $nome . ", você acertou " . $total_acertos . " números e não ganhou nada!<br>";
            }
        ?>
        <br>
        <form method="post" name="form" action="index.php">
            <input type="submit" value="Jogar novamente">
        </form>
        <img src="trevo.png">
    </div>
</body>
</html>
