<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LotoGru</title>
    <link rel="stylesheet" href="loto.css">
</head>
<body>
    <form method="post" name="form" action="lotogru.php">
        <p class = "titulo">LotoGru - Escolha seus números!<img src="trevo.png"></p>
        <p>Digite seu nome:</p>
            <input type="text" name="nome" required>
            <br>
            <br>
        <div class="checkbox-container">
            Selecione 25 números entre 1 e 50: <br>
            <?php
                for ($i = 1; $i <= 50; $i++) {
                    echo '<input type="checkbox" name="valores[]" value="' . $i . '"> ' . $i;
                    if ($i % 10 == 0) echo '<br>'; //inserir quebra de linha a cada 10 números exibidos
                }
            ?>
        </div>

        <br>
        Valor da aposta: <input type="number" name="aposta" required> <br><br>

        <input type="submit" value="Enviar">
    </form>
</body>
</html>
